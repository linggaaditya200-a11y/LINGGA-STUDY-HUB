# LINGGA STUDY HUB

Aplikasi web pengelola file, tugas, dan catatan kuliah. Satu file index.html, tanpa server.
